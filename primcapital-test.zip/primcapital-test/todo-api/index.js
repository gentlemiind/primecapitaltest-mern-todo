const config = require("dotenv").config();

const express = require('express');
const port = 9000;
const app = express();
var cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require("mongoose");
app.use(cors({
    origin: '*'
}));
app.use(bodyParser.json());


mongoose.connect(
    config.parsed.MONGODB_URL, 
    {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }
).then(() => {
    console.log("Databse Connected Successfully!!");    
}).catch(err => {
    console.log('Could not connect to the database', err);
    process.exit();
});
mongoose.set('strictQuery', false);


const todoSchema = new mongoose.Schema({
    id: Number,
    todo: String,
    completed: Boolean
});

const Todo = mongoose.model('Todo', todoSchema);


app.get('/', (request, response) => {
    Todo.find({}, (err, todos) => {
        if (!err) {
            response.status(200).json(todos);
          return;
        }
        console.log(err);
        response.send("Some error occured!")
    }).clone().catch(err => console.log("Error occured, " + err));


});
app.post('/', (request, response) => {
    const newTodo = request.body;
    if (!newTodo.todo || !newTodo.id) return response.status(400).json({ error: "todo field is required!" });
    const todo = new Todo({ id: newTodo.id, todo: newTodo.todo, completed: false });
    todo.save().then(data => {
        response.status(201).json(data)
    }).catch(err => {
        response.status(500).send({
            message: err.message || "Some error occurred while creating todo"
        });
    });
});

app.put('/', (request, response) => {
    const todo = request.body;
    if (!todo.todo || !todo.id) return response.status(400).json({ error: "todo field and id are required!" });
    Todo.findByIdAndUpdate(todo._id, request.body, { useFindAndModify: false }).then(data => {
        if (!data) {
            response.status(404).send({
                message: `todo not found.`
            });
        }else{
            response.status(200).send({ message: "todo updated successfully." })
        }
    }).catch(err => {
        response.status(500).send({
            message: err.message
        });
    });
});

app.delete('/:id', (request, response) => {
    Todo.findByIdAndRemove(request.params.id).then(data => {
        if (!data) {
          response.status(404).send({
            message: `todo not found.`
          });
        } else {
          response.send({
            message: "todo deleted successfully!"
          });
        }
    }).catch(err => {
        response.status(500).send({
          message: err.message
        });
    });
}
);




app.listen(port, () => {
    console.log(`server listening on post : ${port}`);
});