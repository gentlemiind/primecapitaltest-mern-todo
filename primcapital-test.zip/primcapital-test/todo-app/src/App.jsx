import { useEffect, useState } from 'react';
import './App.scss';
import { API_URL } from './utils';





const Todo = ({ todo, onDelete, onUpdate }) => {
  const [currentTodo, setCurrentTodo] = useState(todo);
  const [editing, setEditing] = useState(false);


  const updateTodo = (body)=> {
    fetch(`${API_URL}`, {
      method: 'PUT',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body:   JSON.stringify(body)
    }).then((resp) => resp.json())
      .then(async (json) => {
        console.log(json);
        setEditing(false);
      })
      .catch((err) => {
        console.log(err);
      });
  }
  const toggleTodoState = () => {

    setCurrentTodo({...currentTodo, completed: !currentTodo.completed});
    updateTodo({...currentTodo, completed: !currentTodo.completed})
  }
  const deleteTodo = () => {
    fetch(`${API_URL}${currentTodo._id}`, {
      method: 'DELETE'
    }).then((resp) => resp.json())
      .then(async (json) => {
        console.log(json);
        onDelete();
      })
      .catch((err) => {
        console.log(err);
      });


  }
  return (
    <div className="todo-card">
      {
        !editing ?
          <>


            <div className={currentTodo.completed ? 'todo completed' : 'todo'} >
              {currentTodo.todo}
            </div>

            <div className="options">
              <div className="delete-btn" onClick={deleteTodo}>
                X
              </div>
              <div className="edit-btn" onClick={()=> setEditing(true)}>
                
              </div>
              <div className={currentTodo.completed ? 'done-btn completed' : 'done-btn'} onClick={toggleTodoState}>

              </div>
            </div>
          </>



          :
          <div className="edit-input">
            <input type="text" value={currentTodo.todo} onChange={(e) => setCurrentTodo({ ...currentTodo, todo: e.target.value })} />
            <div className="delete-btn" onClick={()=> setEditing(false)}>
              X
            </div>
            <div className='done-btn' onClick={()=> updateTodo(currentTodo)}>

            </div>
          </div>
      }





    </div>
  )
}


const TodoList = ({ todos = [], onDelete, onUpdate }) => {



  return (
    <div className="todo-list">
      {
        todos.map((todo, idx) => {
          return <Todo todo={todo} key={idx} onDelete={onDelete} onUpdate={onUpdate}/>
        })
      }
    </div>


  );


}


function App() {

  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState({ completed: false, todo: null });

  const getTodos = (cb) => {
    fetch(`${API_URL}`, {
      method: 'GET'
    }).then((resp) => resp.json())
      .then(async (json) => {
        console.log(json);
        setTodos(json);
        cb && cb();
      })
      .catch((err) => {
        console.log(err);
      });
  }


  const addTodo = () => {
    if (!newTodo) return;

    fetch(`${API_URL}`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({...newTodo, id: todos.length + 1})
    }).then((resp) => resp.json())
      .then(async (json) => {
        console.log(json);
        setNewTodo({ ...newTodo, todo: '' });
        getTodos();
      })
      .catch((err) => {
        console.log(err);
      });
  }


  const getPendingTodos = () => {
      getTodos(()=> {
          setTodos(
            todos.filter((todo) => !todo.completed)
          )
      });
  }

  const getCompletedTodos = () => {
    getTodos(()=> {
        setTodos(
          todos.filter((todo) => todo.completed)
        )
    });
}
  

  useEffect(() => {

    getTodos();

  }, []);



  return (
    <div className="app">
      <div className="add-todo">
        <input type="text" placeholder='what do you want to do ?' value={newTodo.todo} onChange={(e) => setNewTodo({ ...newTodo, todo: e.target.value })} />
        <button onClick={addTodo}>add</button>
      </div>
      <div className="categories">
        <div className="category" onClick={getTodos}>
          All
        </div>
        <div className="category" onClick={getPendingTodos}>
          pending
        </div>
        <div className="category" onClick={getCompletedTodos}>
          done
        </div>
      </div>

      <TodoList todos={todos} onDelete={getTodos}  onUpdate={getTodos}/>

    </div>
  );
}

export default App;
