# primecapitaltest-mern-todo
#backend
cd todo-api
npm i
node index.js
#frontend
cd todo-app
npm i
npm start

